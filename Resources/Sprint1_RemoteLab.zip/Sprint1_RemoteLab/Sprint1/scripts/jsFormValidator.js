//This functin will evalute what the user entered
let validateForm = function() {
	
    event.preventDefault();
    let has_User_Entered_A_Search = false;
    

    //Checking what the user typed in the search box 
   // let userSearch = document.forms["myForm"]["SearchBar"].value; 
   
   
	let userSearch = $("SearchBar");
	
	
	
	

    if (userSearch.value == "") 
	{
        alert("Please Enter your search Pretty Please");
        return false;
    } else {
        has_User_Entered_A_Search = true;
    }

     
   

    if (has_User_Entered_A_Search) {
		
        window.location.href = "../views/searchResults.php";
    }

}//end validateForm function 

let sanitizeUserInptu = functin(var userInput){
	
	
	
	
	
}