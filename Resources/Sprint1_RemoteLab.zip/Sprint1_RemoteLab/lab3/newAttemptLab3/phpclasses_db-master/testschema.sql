CREATE TABLE testschema (
id int not null primary key auto_increment,
username varchar(255),
pass varchar(255),
active int
);
