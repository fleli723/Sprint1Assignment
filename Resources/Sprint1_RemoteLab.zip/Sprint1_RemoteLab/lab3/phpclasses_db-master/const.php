<?php

define("MUSER","vidaille_c_admin");
define("MPASS","jon52vor");
define("MSERVER","cnmtsrv1.uwsp.edu");
define("MDB","vidaille_c");

if (basename($_SERVER['PHP_SELF']) == "const.php") {
  die(header("HTTP/1.0 404 Not Found"));
}

?>
